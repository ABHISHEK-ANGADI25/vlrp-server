<div class="w-full h-full flex justify-center items-center opacity-50">
    <div
        class="inline-block h-[10rem] w-[10rem] animate-spin rounded-full border-8 border-solid border-secondary border-r-tertiary align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"
        role="status">
    </div>
</div>
  